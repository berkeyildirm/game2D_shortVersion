using UnityEngine;
using System.Collections;

public class CollectableHealth : MonoBehaviour
{
    [SerializeField] private SpriteRenderer _spriteRenderer;
    [SerializeField] private float _increaseValue;
    [SerializeField] private float _spawnDelay;

    private bool _canCollect = true;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!_canCollect) return;

        if (collision.gameObject.TryGetComponent<PlayerStats>(out var p))
        {
            p.IncreaseHealth(_increaseValue);
            StartCoroutine(OnCollect());
        }
    }

    private IEnumerator OnCollect()
    {
        SetActive(false);

        yield return new WaitForSeconds(_spawnDelay);

        SetActive(true);
    }

    private void SetActive(bool val)
    {
        _spriteRenderer.enabled = val;
        _canCollect = val;
    }
}
