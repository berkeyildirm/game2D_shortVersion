using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationLocker : MonoBehaviour
{
    [SerializeField] private bool _lockX;
    [SerializeField] private bool _lockY;
    [SerializeField] private bool _lockZ;

    [SerializeField] private float _lockValueX;
    [SerializeField] private float _lockValueY;
    [SerializeField] private float _lockValueZ;

    private void LateUpdate()
    {
        if (_lockX)
            transform.rotation = Quaternion.Euler(_lockValueX, transform.localRotation.y, transform.localRotation.z);
        if (_lockY)
            transform.rotation = Quaternion.Euler(transform.localRotation.x, _lockValueY, transform.localRotation.z);
        if (_lockZ)
            transform.rotation = Quaternion.Euler(transform.localRotation.x, transform.localRotation.y, _lockValueZ);
    }
}
