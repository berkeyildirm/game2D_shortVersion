using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class FinishManager : MonoBehaviour
{
    private static FinishManager _ins;
    public static FinishManager Ins
    {
        get
        {
            if (!_ins)
                _ins = FindObjectOfType<FinishManager>();
            return _ins;
        }
    }

    [SerializeField] private SpriteRenderer _door;
    [SerializeField] private Sprite _openDoorSprite;
    [SerializeField] private int _targetEnemyCount;

    private List<Entity> _entityList = new();

    public void SetEnemyList(Entity enemy)
    {
        _entityList.Add(enemy);
        CheckTarget();
    }

    private void CheckTarget()
    {
        if (_entityList.Count == _targetEnemyCount)
        {
            _door.sprite = _openDoorSprite;
            _door.gameObject.GetComponent<BoxCollider2D>().enabled = false;
        }
    }

    public void OnFinish()
    {
        StartCoroutine(LoadScene());
    }

    private IEnumerator LoadScene()
    {
        yield return new WaitForSeconds(3);

        SceneManager.LoadScene(3);
    }
}
