using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Berke
{
    public class MainMenu : MonoBehaviour
    {
        
        void Start()
        {
            
        }

        void Update()
        {

        }

        public void GoToMain()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene("MainStory");
        }

        public void QuitGame()
        {
            Application.Quit();
        }
    }
}
