using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Berke
{
    public class MainStory : MonoBehaviour
    {
        void OnEnable()
        {
            SceneManager.LoadScene("Main", LoadSceneMode.Single);
        }
    }
}
