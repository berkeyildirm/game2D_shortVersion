using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FiniteStateMachine : MonoBehaviour
{
    public State currentState { get; private set; }

    // Gets the current State
    public void Initialize(State startingState)
    {
        currentState = startingState;
        currentState.Enter();
    }

    // Changing the State
    public void ChangeState(State newState)
    {
        currentState.Exit();
        currentState = newState;
        currentState.Enter();
    }
}
